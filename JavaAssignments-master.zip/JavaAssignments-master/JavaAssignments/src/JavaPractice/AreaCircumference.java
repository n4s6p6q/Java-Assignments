package JavaPractice;

public class AreaCircumference {

	public static void main(String[] args) {
		
		int radius = 5;
		
		double area;
		
		double circum;
		
		area = 3.14*radius*radius;
		
		circum = 2*3.14*radius;
		
		System.out.println("Area: " +area);
		
		System.out.println("Circumference: " +circum);

	}

}
