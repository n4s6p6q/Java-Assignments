package JavaPractice;

import java.util.Scanner;

public class PowerCalculator {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the base: ");
        
        int base = scanner.nextInt();

        System.out.print("Enter the exponent: ");
        
        int exponent = scanner.nextInt();

        // Calculate and print the result using a for loop
        
        long result = 1; // Use 'long' to handle larger results
        
        for (int i = 0; i < exponent; i++) 
        {
            result = result * base;
        }

        System.out.println(base + " raised to the power of " + exponent + " is: " + result);

	}

}
