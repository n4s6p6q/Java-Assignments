package JavaPractice;

public class PatternNumbers {

	public static void main(String[] args) {
		
		int N = 10;
		
		for(int i=3;i<=N;i++)
		{
			int Num = 3*i;
			
			System.out.println(Num);
		}
			
	}

}
